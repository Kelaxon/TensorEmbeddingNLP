Each line of the truth files encodes the following information:
userid:::gender:::age_group:::extroverted:::stable:::agreeable:::conscientious:::open

